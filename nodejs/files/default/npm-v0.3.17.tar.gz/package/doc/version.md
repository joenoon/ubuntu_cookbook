npm-version(1) -- Bump a package version
========================================

## SYNOPSIS

    npm version <newversion>

## DESCRIPTION

Run this in a package directory to bump the version and write the new
data back to the package.json file.

If run in a git repo, it will also create a version commit and tag, and
fail if the repo is not clean.
