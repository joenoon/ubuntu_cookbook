npm-remote(1) -- Execute commands on a remote machine
=====================================================

## FUTURE

This functionality does not yet exist.

## SYNOPSIS

    npm remote <commands>

## DESCRIPTION

Run a command on a remote npm site instance.

In order to do this, the current authenticated user must be in
the "admin" list on the server, and it must be running with https
support.

It uses the `host` config to know where to do things.



