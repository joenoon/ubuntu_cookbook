#!/usr/bin/env node
require("./bin/npm.js")
